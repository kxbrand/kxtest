//test/dynamic.js
module.exports = function(req, res, next) {
  var user_name=req.body.user; //读取 post user 参数
  if(user_name == "json1"){
  	res.json(require('./json1.json'))
  }else{
  	res.json(require('./json2.json'))
  }
};
//test/dynamic2.js
module.exports = function(req, res, next) {
  var user_name=req.body.user; //读取 post user 参数
  var data = {
  	"username":user_name//,
  	//"id":query_param
  };//mock data
  res.json(data);
};
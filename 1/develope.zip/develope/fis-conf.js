fis.set('livereload.hostname', '127.0.0.1');
//fis.set('freemarker.views', 'views');
fis.media('dev')
.match('**', {
  useHash: false,
  deploy:[fis.plugin('local-deliver', {
    to:'../.build'
  })]
})